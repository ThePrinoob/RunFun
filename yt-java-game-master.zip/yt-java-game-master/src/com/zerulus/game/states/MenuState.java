package com.zerulus.game.states;

import com.zerulus.game.graphics.Screen;
import com.zerulus.game.util.KeyHandler;
import com.zerulus.game.util.MouseHandler;

public class MenuState extends GameState {
    public MenuState(GameStateManager gsm) {
        super(gsm);
    }

    @Override
    public void update(double time) {

    }

    @Override
    public void input(MouseHandler mouse, KeyHandler key) {

    }

    @Override
    public void render(Screen s) {

    }
}
