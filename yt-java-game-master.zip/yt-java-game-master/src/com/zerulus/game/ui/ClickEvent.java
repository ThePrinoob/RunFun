package com.zerulus.game.ui;

public interface ClickEvent {
    public void action(int mouseButton);
}