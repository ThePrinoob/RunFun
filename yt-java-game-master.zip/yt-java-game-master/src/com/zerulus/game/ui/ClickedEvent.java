package com.zerulus.game.ui;

public interface ClickedEvent {
    void action(int mouseButton);
}